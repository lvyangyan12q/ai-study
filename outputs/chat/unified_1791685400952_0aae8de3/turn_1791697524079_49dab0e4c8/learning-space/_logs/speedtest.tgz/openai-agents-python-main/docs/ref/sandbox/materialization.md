# `Materialization`

::: agents.sandbox.materialization
