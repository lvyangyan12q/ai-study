# `Events`

::: agents.voice.events
